<?php
require 'includes/head.php';
require 'includes/register.php';
?>


<?php if (!empty($erreurs)): ?>
  <div class="alert alert-danger">

    <p>Vous n'avez pas rempli le formulaire correctement !</p>
      <ul>

        <?php foreach ($erreurs as $erreur): ?>
          <li><?= $erreur; ?></li>
        <?php endforeach; ?>

      </ul>
  </div>
<?php endif; ?>


<!-- MAIN -->
<section id="signup">

  <div class="wrapper body-inverse"> <!-- wrapper -->
    <div class="container">
      <div class="row">

      <!-- Sign Up form -->
    <div class="col-sm-5 col-md-offset-3 col-md-6">
      <h3 class="text-center">Inscription</h3>

    <div class="form-white">
      <form role="form" action="" method="POST">
        <div class="form-group">
          <label for="name">Prénom :</label>
        <input type="text" class="form-control" name="first" placeholder="Prénom">
        </div>
        <div class="form-group">
          <label for="name">Nom :</label>
        <input type="text" class="form-control" name="last" placeholder="Nom">
        </div>
        <div class="form-group">
          <label for="username">Identifiant :</label>
        <input type="text" class="form-control" name="uid" placeholder="Identifiant">
        </div>
        <div class="form-group">
          <label for="email2">Adresse E-mail :</label>
        <input type="email" class="form-control" name="email" placeholder="Adresse E-mail">
        </div>
        <div class="form-group">
          <div class="form-group">
          <label for="password2">Mot de passe :</label>
          <input type="password" class="form-control" name="pwd" placeholder="Mot de passe">
          </div>
        </div>
        <button type="submit" name="submit" class="btn btn-block btn-primary btn-xxl">S'inscrire !</button>
      </form>
    </div>
    </div>
  </div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>

</section>
