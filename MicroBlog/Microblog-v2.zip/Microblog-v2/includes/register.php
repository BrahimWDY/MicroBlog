<?php

  require_once 'includes/bootstrap.php';


  if(!empty($_POST)){

    // on stock les erreurs dans un tableau

    $errors = array();

    // On appelle la base de donnée

    $db = App::getDatabase();

    // Validation des données

    $validator = new Validator($_POST);
    $validator->alpha('uid', "Votre identifiant n'est pas valide !");
    $validator->uniqUid('user_uid', $db, 'users', "Cet identifiant est déjà pris !");
    $validator->email('email', "Votre email n'est pas valide !");
    $validator->uniqEmail('user_email', $db, 'users', "Cet email est déjà utilisé pour un autre compte !");
    $validator->pwdConfirmed('pwd', "Vous devez rentrer un mot de passe valide !");
    $validator->first('first', "Vous devez remplir tout les champs !");
    $validator->last('last', "Vous devez remplir tout les champs !");


    if ($validator->isValid()) {


      $auth = new Auth($db);
      $auth->register($_POST['first'],$_POST['last'],$_POST['uid'],$_POST['pwd'],$_POST['email']);

      $session = new Session();
      Session::getInstance()->setFlash('success', 'Vous êtes inscrit !');

      App::redirect('login.php');


    }else {

      $errors = $validator->getErrors();

    }



    // Si il n'y a aucune erreurs alors on accéde à la base de donnée

    // if(empty($errors)){
    //
    //   // si il n'y a aucune erreur alors on insert le formulaire dans la base de donnée et on dirige l'utilisateur vers la page connexion
    //
    //   require 'includes/db.php';
    //
    //   // ERREUR ICI
    //
    //   // header ("Location: ../login.php");
    //   // exit();
    //
    // }

  }

?>
