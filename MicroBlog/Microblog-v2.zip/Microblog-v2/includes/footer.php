<!-- FOOTER -->

<footer>
  <div class="copyright">
    Copyright (c) 2018 Brahim Ouarradi.
  </div>
</footer>

</body>
</html>
