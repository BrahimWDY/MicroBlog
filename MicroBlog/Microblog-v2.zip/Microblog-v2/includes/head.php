<?php require_once 'includes/bootstrap.php'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>MicroBlog</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">



  </head>
  <body>



    <!-- HEADER -->

    <header>
      <div class="title">
        <a href="index.php">MicroBlog</a>
      </div>
    </header>


  <div class="container">
    <?php if(Session::getInstance()->hasFlashes()): ?>
      <?php foreach (Session::getInstance()->getFlashes() as $type => $message): ?>
        <div class="alert alert-<?= $type; ?>">
          <?= $message; ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
