<?php

// On démarre la session

session_start();
require 'includes/bootstrap.php';
require 'includes/register.php';

?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Timeline</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

  </head>
  <body>

    <header>
      <div class="title">
        Timeline
      </div>
    </header>

    <section>

      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">
            <div class="panel panel-default">
              <div class="panel-heading">  <h4 class="profil">Profil</h4></div>
                <div class="panel-body">
                  <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8" >

                  <div class="container">
                    <h2><?php
                    if (isset($_SESSION['user_first'])) {
                      echo $_SESSION['user_first'] . " " . $_SESSION['user_last'];
                      } else {

                      }
                     ?></h2>
                  </div>

                   <hr>

                  <ul class="container details" >
                    <li><p><span class="glyphicon glyphicon-user one" style="width:50px;"></span><?php if   (isset($_SESSION['user_uid'])) {
                      echo $_SESSION['user_uid'];
                      } else {

                      } ?></p></li>
                    <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php if   (isset($_SESSION['user_email'])) {
                      echo $_SESSION['user_email'];
                      } else {

                      } ?></p></li>
                  </ul>
                  <hr>

                  <div class="date">
                    <div class="col-sm-12 col-xs-12" >Date d'inscription <?php if(isset($_SESSION['user_date'])){
                                                                                echo $_SESSION['user_date'];
                                                                                } ?>
                    </div>
                  </div>

                  <hr>

                  <form action="includes/logout.php" method="POST">
                    <button class="btn btn-danger" type="submit" name="submit">Se déconnecter</button>
                  </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    </section>

  </body>
</html>
