<?php

// On vérifie que les champs sont rempli

if (!empty($_POST) && !empty($_POST['uid']) && !empty($_POST['pwd'])) {

  // On se connecte à la base de donnée

  require 'includes/dbexe.php';

  // On prepare la requete
// ---> ma correction Fréro:
// ---> dans votre requete $req apres OR user_email = :uid au lieu de :email
  $req = $pdo->prepare('SELECT * FROM users WHERE (user_uid = :uid OR user_email = :uid ) AND user_date IS NOT NULL');

  // On l'execute
  // ERREUR ICI
  // ---> ma correction Fréro:
  // ---> dans votre execute
  // la fonction execute accepte des attribus par ARRAY donc j'ai ajouté tes attribus dans un ARRAY
  $req->execute(array(':uid' => $_POST['uid']));
  $user = $req->fetch();

  if(password_verify($_POST['pwd'], $user->user_pwd)){

    $_SESSION['auth'] = $user;

    $_SESSION['flash']['success'] = 'Vous êtes connecté';
    // le probleme ici que tu as déja utiliser HEADER donc tu peux pas l'utiliser ici
    // trouve une autre méthode pour redirectionner
    // moi j'ai mets une redirection avec une balise HTML mais sinon tu peux faire d'autre
    ?>
    <meta http-equiv="refresh" content="1;url=timeline.php"/>
    <?php
    // header("Location: timeline.php");
    // exit();

  } else {

    $_SESSION['flash']['danger'] = 'Identifiant ou Mot de passe incorrect !';

  }
}

?>
