<?php


  require_once 'includes/bootstrap.php';


  if(!empty($_POST)){

    // on stock les erreurs dans un tableau

    $erreurs = array();

    // On appelle la base de donnée

    $db = app::getDatabase();

    // Si le champ identifiant est vide alors on execute la variable $erreurs
    // L'identifiant doit être alphanumérique !

    if( empty($_POST['uid']) || !preg_match('/^[a-zA-Z0-9_]+$/', $_POST['uid']) ){

      $erreurs['uid'] = "Votre identifiant n'est pas valide !";

    } else {

      // On vérifie si il y a un identifiant identique dans la base de donnée, si oui on exécute la variable $erreurs

      $user = $db->query('SELECT user_uid FROM users WHERE user_uid = ?', [$_POST['uid']])->rowCount();


      if($user === 1){

        $erreurs['uid'] = "Cet identifiant est déjà pris !";

      }
    }

    // Si l'email n'est pas valide alors execute la variable $erreurs

    if( empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){

      $erreurs = "Votre email n'est pas valide !";

    } else {

      // On vérifie si il y a un email identique dans la base de donnée, si oui on exécute la variable $erreurs

      $user = $db->query('SELECT user_email FROM users WHERE user_email = ?', [$_POST['email']])->rowCount();

      if($user === 1){

        $erreurs['email'] = "Cet email est déjà utilisé pour un autre compte !";

      }
    }

    // Vérifier si le mot de passe est valide sinon on execute la variable $erreurs

    if (empty($_POST['pwd'])){

      $erreurs = "Vous devez rentrer un mot de passe valide !";
    }

    // Vérifier si les champs nom & prénom sont remplis sinon on execute la variable $erreurs

    if (empty($_POST['first']) || empty($_POST['last'])){

      $erreurs = "Vous devez remplir tout les champs !";
    }

    // Si il n'y a aucune erreurs alors on accéde à la base de donnée

    if(empty($erreurs)){

      // si il n'y a aucune erreur alors on insert le formulaire dans la base de donnée et on dirige l'utilisateur vers la page connexion

      require 'includes/db.php';

?>
    <meta http-equiv="refresh" content="1; URL=login.php">;

<?php

    }

  }

?>
