<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>MicroBlog</title>

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">



  </head>
  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <a href="index.php" class="navbar-brand">MicroBlog</a>
        </div>

      </div>

    </nav>

    <!-- HEADER -->

    <!-- <header>
      <div class="title">
        <a href="index.php">MicroBlog</a>
      </div>
    </header> -->
