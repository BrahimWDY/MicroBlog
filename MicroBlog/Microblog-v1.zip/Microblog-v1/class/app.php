<?php

  class app{

    static $db = null;

    static function getDatabase(){

      if(!self::$db){

        self::$db = new Database('root', 'root', 'microblog');

      }
      
      return self::$db;
    }
  }

?>
